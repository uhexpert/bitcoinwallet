# RBW - Ruby bitcoin wallet

import requests, json, hashlib, random, os, binascii, ecdsa, base58, time, PySimpleGUIWeb as sg, datetime, importlib



print('Starting...')

def tim():
    tim = datetime.datetime.now()
    return (tim.strftime("%Y-%m-%d %H:%M:%S"))

def get():
    URL = 'https://www.bitstamp.net/api/ticker/'
    try:
        r = requests.get(URL)
        priceFloat = float(json.loads(r.text)['last'])
        return priceFloat
    except requests.ConnectionError:
        print ("Error querying Bitstamp API")

def eu():
    url = 'https://www.bitstamp.net/api/v2/ticker/btceur/'
    try:
        r = requests.get(url)
        bteth = float(json.loads(r.text)['last'])
        return bteth
    except requests.ConnectionError:
        print ("Error querying Bitstamp API")



        
sg.ChangeLookAndFeel('LightGrey')
layout =  [
            [sg.Text('Date & Time:', font=('Helvetica', 13), size=(15,1)),sg.Text('', size=(30,1), font=('Helvetica', 13), key='_DATE_')],
            [sg.Text('1 BTC:', font=('Helvetica', 13), size=(15,1)), sg.Text('', size=(15,1), font=('Helvetica', 13),  key='coin'),sg.Text('1 BTC:', font=('Helvetica', 13), size= (15,1)), sg.Text('', size=(15,1), font=('Helvetica', 13),  key='euro')],
            [sg.Text('Name:', font=('Helvetica', 13),size=(15,1)), sg.InputText(size=(15,1), font=('Helvetica', 13), text_color='white', key = 'name'), sg.Text('Surname:', font=('Helvetica', 13), size=(15,1)), sg.InputText(size=(15,1),font=('Helvetica', 13), key = 'surname', text_color='white')],
            [sg.Text('Username:', font=('Helvetica', 13),size=(15,1)), sg.InputText(size=(15,1), font=('Helvetica', 13), text_color='white', key = 'username')],
            [sg.Text('e-mail:', font=('Helvetica', 13), size=(15,1)), sg.InputText(size=(15,1), font=('Helvetica', 13), text_color='white', key = 'email')],
            [sg.Text('Birthdate:', font=('Helvetica', 13), size=(15,1)), sg.InputText(size=(15,1), font=('Helvetica', 13), text_color='white', key = 'birthdate')],
            [sg.Text('Password:', font=('Helvetica', 13), size=(15,1)), sg.InputText(size=(15,1), font=('Helvetica', 13), text_color='white', key = 'password')],
            [sg.Text('Address:', font=('Helvetica', 13),size=(15,1)), sg.Text('', size=(30,1), font=('Helvetica', 13),  key='generator')],
            [sg.Text('Privatekey:',font=('Helvetica', 13), size=(15,1)), sg.Text('', size=(30,1), font=('Helvetica', 13), key='privatekey')],
            [sg.Text('WIF:', font=('Helvetica', 13), size=(15,1)), sg.Text('', size=(30,1), font=('Helvetica', 13), key='wif')],
            [sg.Button('Generate wallet', font=('Helvetica', 12))]]


window = sg.Window('RBW-Ruby bitcoin wallet',
                  layout=layout,
                   default_element_size=(12,1),
                   font='Helvetica 18',
                   )





while True:
    time = tim()
    coinprice = get()
    btceuro = eu()
    
    event, values = window.Read(timeout=10)# read with a timeout of 10 ms
    if event == 'Generate wallet': # if got a real event, print the info
        a = values['name']
        b = values['surname']
        c = values['username']
        d = values['email']
        e = values['birthdate']
        f = values['password']
        g = a+b+c+d+e+f
        secret_exponent = hashlib.sha256(g.encode("utf-8")).hexdigest()
        key = binascii.unhexlify(secret_exponent)
        s = ecdsa.SigningKey.from_string(key, curve = ecdsa.SECP256k1)
        public_key = '04' + binascii.hexlify(s.verifying_key.to_string()).decode('utf-8')
        output = []; alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
        var = hashlib.new('ripemd160')
        var.update(hashlib.sha256(binascii.unhexlify(public_key.encode())).digest())
        var = '00' + var.hexdigest() + hashlib.sha256(hashlib.sha256(binascii.unhexlify(('00' + var.hexdigest()).encode())).digest()).hexdigest()[0:8]
        count = [char != '0' for char in var].index(True) // 2
        n = int(var, 16)
        while n > 0:
            n, remainder = divmod(n, 58)
            output.append(alphabet[remainder])
        for i in range(count): output.append(alphabet[0])
        address = ''.join(output[::-1])
        var80 = "80"+secret_exponent
        var = hashlib.sha256(binascii.unhexlify(hashlib.sha256(binascii.unhexlify(var80)).hexdigest())).hexdigest()
        WIF = str(base58.b58encode(binascii.unhexlify(str(var80) + str(var[0:8]))))
        data = open("Wallet.txt","a")
        data.write("Wallet: "+"\n\n" + "Name:       "+ str(a) +"\n"+"Surname:    "+ str(b) +"\n"+"Username:   "+ str(c) +"\n"+"e-mail:     "+ str(d) +"\n"+"Birth date: "+ str(e) +"\n"+"Password:   "+ str(f) +"\n"+"Address:    "+str(address)+"\n"+ "Privatekey: " +str(secret_exponent)+"\n"+"Publickey:  " + str(public_key)+"\n"+"WIF:        " +str(WIF)+"\n\n"+'-------------------------------------------------------------------------------------------------------------------------------'+"\n\n")
        data.close()
        window.Element('generator').Update(str(address))
        window.Element('privatekey').Update(str(secret_exponent))
        window.Element('wif').Update(str(WIF))

    elif event in (None, 'Exit'):
        break
    window.Element('_DATE_').Update(str(time))
    window.Element('coin').Update(str(coinprice)+' $')
    window.Element('euro').Update(str(btceuro)+' €')


window.Close()
print('Completed shutdown')

