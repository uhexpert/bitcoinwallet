RBW - Ruby Bitcoin Wallet
![Ruby wallet](n1.png)

How it works:
```
From name, surname, username, e-mail, birthdate and password create bitcoin
privatekey and then convert it to Wallet Interchange Format key (WiF) format, 
which is a Base-58 form for the random key. 
This is the format that is stored in the Bitcoin Wallet. 


For example a sample private key is generated from:

name+surname+username+e-mail-birthdate

0345107e6426a08af5985fd378904ed65753dc3d6e4349483b4e7bfb36dfde1f

We then convert this into WiF format (Base-58):

5Hqj6yBkZqkLkdYvMfFGDNjV26ANH7KdSVZ5CmyVJGYNL4BGwg9

This can be stored in a Bitcoin wallet. Next we can take then private key and a 
hash value, and covert it into a useable Bitcoin address, such as:

1GuCQS5Dja7fYahLD5BrxPWVMYFLBDaFsd

The format of the keys is defined below, where we create a 256-bit private key 
and convert this to a WiF private key. Next we generate a 512-bit public key, 
and then take a 160-bit RIPEM-160 hash and convert to a Bitcoin address:

```
![Ruby wallet](bithash.png)




Usage:

```
Python3:


cd RBW-Ruby-bitcoin-wallet

pip3 install -r requirements.txt

python3 rbw.py



Windows:


start rbw.exe

```
Sample:

```
-------------------------------------------------------------------------------------------------------------------------------

Wallet: 

Name:       test
Surname:    test
Username:   test
e-mail:     test@hotmail.com
Birth date: 11.11.1984
Password:   testing
Address:    1Q2tdWVGzdNNVeKq6mNY4XNn5Pum3ANFZ5
Privatekey: f043ed808df475acc29ca5ced5347cadbddab157f10b4b2b04eb0cf6d881cca3
Publickey:  04908868764da5f1bd699d0ce157498d7966c384bb6e77c263993b08d7139d08ee3e3ec93a4a65d6664a0a5165c528b871f8bb42951b137c49029894af19143ec1
WIF:        b'5Ke6qWfDx4eDrcQ6qzJytMnVu4VKThNUEBGdBTkXne3PDLHERrn'

-------------------------------------------------------------------------------------------------------------------------------
```
![Ruby wallet](no.png)


Donate small amount of Btc to support my project 33hJyoqkCfQQMABZ4ea1DxqwwZfK5iPrVZ

